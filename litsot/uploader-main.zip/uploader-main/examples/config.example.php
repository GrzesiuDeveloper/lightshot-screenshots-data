<?php

return [
    'client_id' => '48b6xxxxxxxxxxx',
    'client_secret' => 'fd5048fxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx',
];